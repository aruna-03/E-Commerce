import { Component, OnInit } from '@angular/core';
import { product } from '../data-type';
import { Product } from '../data-type';
import { ProductService } from '../services/product.service';
@Component({
  selector: 'app-seller-home',
  templateUrl: './seller-home.component.html',
  styleUrls: ['./seller-home.component.css']
})
export class SellerHomeComponent implements OnInit {
  productList: undefined | product[];
  productMessage: undefined | string;
  constructor(private product: ProductService) { }
  products: Product[] = [{"imageUrl": './assets/images/clock.jpg'},
     {"imageUrl": './assets/images/mug.jpg'},
     {"imageUrl": './assets/images/cutter.jpg'},
     {"imageUrl":'./assets/images/nightlamp.jpg'},
    {"imageUrl":'./assets/images/kitchen.jpg'},
    {"imageUrl":'./assets/images/bedsheet.jpg'},
    {"imageUrl":'./assets/images/scentedcandles.jpg'},
    {"imageUrl":'./assets/images/salt.jpg'}];
  ngOnInit(): void {
    this.list(); 
  }
  list() {
    this.product.productList().subscribe((result) => {
      if (result) {
        this.productList = result;
      }
    });
  }

}
